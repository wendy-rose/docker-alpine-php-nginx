<?php

namespace Swoole\Curl;

use Swoole;

class Exception extends Swoole\Exception
{

}